
INSERT INTO "USER"
    (ID, USERNAME, PASSWORD, EMAIL, FIRST_NAME, LAST_NAME, ROLE)
VALUES
    (1, 'admin', 'admin123', 'admin@example.com', 'Admin', 'User', 'ADMIN'),
    (2, 'librarian', 'lib123', 'librarian@example.com', 'Lib', 'User', 'LIBRARIAN'),
    (3, 'student', 'stud123', 'student@example.com', 'Student', 'User', 'STUDENT');

INSERT INTO BOOK
    (ID, TITLE, AUTHOR, CATEGORY, TOTAL_COPIES, AVAILABLE_COPIES, PUBLISHED_YEAR, RATING, DESCRIPTION)
VALUES
    (1, 'Clean Code', 'Robert Martin', 'Textbook', 10, 10, 2008, 4.5, 'A handbook of Agile software craftsmanship.'),
    (2, 'The Pragmatic Programmer', 'Andrew Hunt', 'Textbook', 5, 5, 1999, 4.7, 'Your journey to mastery of software development.'),
    (3, 'Harry Potter and the Sorcerer''s Stone', 'J.K. Rowling', 'Fiction', 15, 12, 1997, 4.8, 'The first book in the Harry Potter series.'),
    (4, 'Atomic Habits', 'James Clear', 'Non-Fiction', 8, 8, 2018, 4.6, 'An easy & proven way to build good habits.');

